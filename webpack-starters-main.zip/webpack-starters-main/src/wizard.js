export const wizard = "Ravalynn";
