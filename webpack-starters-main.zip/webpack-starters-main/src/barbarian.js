export const barbarian = "Hjulmar";
